
let CSV = ''




chrome.runtime.onMessage.addListener(
    async function (request, sender, sendResponse) {

        if (request.greeting === "download") {
            chrome.runtime.sendMessage({ url: "hello" })
            
        }
        if (request.pushback) {
            var element = document.createElement('a');
            element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(request.pushback));
            element.setAttribute('download', "cookies.txt");

            element.style.display = 'none';
            document.body.appendChild(element);

            element.click();

            document.body.removeChild(element);
            // scrape buttons here
            
            btns = document.querySelectorAll('.btn-link')
            //ss = card.get_attribute('onclick')
            //ss = ss.replace('javascript:open_pdf(','').replace(');','').replace("'",'').split(',')
            for (let btn of btns) {
                let row = ''
                let attr = btn.getAttribute('onclick');
                let title = btn.querySelector('font').textContent
                row = '"' + attr + '",' + '"' + title + '"'
                CSV += row + '\r\n'
            }
            var element = document.createElement('a');
            element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(CSV));
            element.setAttribute('download', "scr.csv");

            element.style.display = 'none';
            document.body.appendChild(element);

            element.click();

            document.body.removeChild(element);
        }

    }


);

/*
            links = ['#link_0','#link_1','#link_2','#link_3']
            links.forEach(idd => {
                
                btn = document.querySelector(idd)
                btn.click()
            });
            */

