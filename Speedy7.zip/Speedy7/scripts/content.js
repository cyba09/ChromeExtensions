

function findShortestCombination(target, values, memo = {}) {
    if (target in memo) return memo[target];
    if (target === 0) return [];
    if (target < 0) return null;

    let shortestCombination = null;

    for (let value of values) {
        const remainder = target - value;
        const remainderCombination = findShortestCombination(remainder, values, memo);

        if (remainderCombination !== null) {
            const combination = [value, ...remainderCombination];
            if (shortestCombination === null || combination.length < shortestCombination.length) {
                shortestCombination = combination;
            }
        }
    }

    memo[target] = shortestCombination;
    return shortestCombination;
}



chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {


        if (request.greeting) {
            const buttonValues = [1, 3, 5, 10];
            const buttons = {
                1: document.querySelector('[data-qa="amount-selector-button-1"]'),
                3: document.querySelector('[data-qa="amount-selector-button-3"]'),
                5: document.querySelector('[data-qa="amount-selector-button-5"]'),
                10: document.querySelector('[data-qa="amount-selector-button-10"]')
            };


            /////////////////////////////

            //////////////////////////////////////////
            function simulateClicks(combination) {
                if (!combination) {
                    console.log('No combination found');
                    return;
                }
    
                combination.forEach((value, index) => {
                    setTimeout(() => {
                        if (buttons[value]){
                            buttons[value].click();
                        }
                        
                    }, 50 * index);
                });
            }///////////////////////////
            // Example: Find combination for 24 and simulate clicks
            const targetValue = parseInt(request.greeting);
            const combination = findShortestCombination(targetValue, buttonValues);
            const ten = document.querySelector('[data-qa="amount-selector-button-10"]');

            //console.log('Combination:', combination);
            //const runId = document.querySelector('[data-qa="text-game-draw-code"]')
            //console.log(runId.textContent)
            simulateClicks(combination);

            // Example: Add click event listeners for demonstration
            /*
            Object.values(buttons).forEach(button => {
                button.addEventListener('click', () => {
                    console.log('Button clicked:', button.value);
                });
            });
            */

        }
        if (request.clear){
            const clear = document.querySelector('[data-qa="amount-selector-button-clear"]');
            clear.click()
        }

    }
);


//data-qa="amount-selector-button-clear"
//amount-selector-button-10
//amount-selector-button-5
//amount-selector-button-3
//amount-selector-button-1
//data-qa="betting-option-red"
const ten = document.querySelector('[data-qa="amount-selector-button-10"]');
//betgames_iframe  //
//src  src="https://webiframe.betgames.tv/auth?apiUrl=https%3A%2F%2Fgame3.betgames.tv&partnerUrl=https%3A%2F%2Fwww.betway.co.za%2Flobby%2Fbetgames%2Flaunchgame%2Fbetgames%2Fbetgames%2Fspeedy-7&partnerCode=betway_co_za&token=f8544aaf-1227-ef11-8186-00155da51021&locale=en&timezone=2&gameId=11&homeUrl=https%3A%2F%2Fwww.betway.co.za&defaultGUI=0&newIntegration=1&scriptIntegration=1"