

chrome.runtime.onMessage.addListener(notify);
//'https://randomuser.me/api/'
function notify(message) {
  if (message.url){
    //console.log(message.url)
    downloadCSV(message.url, "LinkedInPosts.csv");
  }




}

function downloadCSV(csvContent, filename) {
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent);

  chrome.downloads.download({
    url: url,
    filename: filename,
    conflictAction: 'uniquify', // Optional: Choose what to do if a file with the same name already exists
  });
}