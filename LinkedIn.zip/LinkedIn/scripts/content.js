function allSame(array) {
    // Using Set to get unique values in the array
    const uniqueValues = new Set(array);

    // If the size of the Set is 1, then all elements are the same
    return uniqueValues.size === 1;
}
function downloadCsv() {
    chrome.runtime.sendMessage({ url: CSV })
    /*
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(CSV));
    element.setAttribute('download', "LinkedInPosts.csv");

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);*/
}





let num = 110
let runn = false
let checkList = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18]
let stWhole = ''
let CSV = '"Author"% "Date"% "Likes"% "Comments"% "Post"' + '\r\n'
let nIntervId = ''
let txt = 'Peace in our time'



chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {


        if (request.greeting === "download") {


            nIntervId = setInterval(() => {
                window.scrollBy(0, 1000);
                let lenLst = document.querySelectorAll('li.profile-creator-shared-feed-update__container')   //li.profile-creator-shared-feed-update__container:nth-child(3)
                console.log(lenLst.length)
                checkList.shift()
                checkList.push(lenLst.length)
                //let lastNode = lenLst[lenLst.length - 1]
                //let txt = lastNode.querySelector('h3.x1heor9g > span').textContent
                //let nme = lastNode.querySelector('h3.x1heor9g > span > a').textContent
                //let allID = lastNode.querySelector('.xdj266r > div[dir="auto"]').textContent
                //let postID = allID[3].getAttribute('href')
                //console.log(allID)
                if (allSame(checkList)) {
                    console.log('finished')
                    clearInterval(nIntervId);
                    function scrapeData() {
                        lenLst.forEach(card => {
                            let row = ''
                            let nme = ''
                            let dte = ''
                            let likes = ''
                            let comments = ''
                            let post = ''
                            let commentsTrimmed = ''
                            try {
                                nme = card.querySelector('.update-components-actor__name').textContent.trim()

                            }
                            catch {
                                nme = 'Null'
                            }
                            try {
                                dte = card.querySelector('a.update-components-actor__sub-description-link').getAttribute('aria-label')

                            }
                            catch {
                                dte = 'Null'
                            }
                            try {
                                likes = card.querySelector('.social-details-social-counts__reactions-count').textContent.trim()

                            }
                            catch {
                                likes = 'Null'
                            }
                            try {
                                comments = card.querySelector('li.social-details-social-counts__comments').textContent.trim()
                                commentsTrimmed = parseInt(comments)

                            }
                            catch {
                                comments = 'Null'
                            }
                            try {
                                post = card.querySelector('.update-components-text > span').textContent.trim()

                            }
                            catch {
                                post = 'Null'
                            }
                            //console.log(nme)
                            row = '"' + nme + '"%' + '"' + dte + '"%' + '"' + likes + '"%' + '"' + commentsTrimmed + '"%' + '"' + post + '"'
                            CSV += row + '\r\n'

                        });
                    }
                    
                    setTimeout(scrapeData, 1000);
                    setTimeout(downloadCsv, 3000);
                }
                
            }, 1000, num)


        }

        if (request.greeting === "stop") {
            clearInterval(nIntervId)
            let lenLst = document.querySelectorAll('li.profile-creator-shared-feed-update__container')
            

            function scrapeData() {
                lenLst.forEach(card => {
                    let row = ''
                    let nme = ''
                    let dte = ''
                    let likes = ''
                    let comments = ''
                    let post = ''
                    let commentsTrimmed = ''
                    try {
                        nme = card.querySelector('.update-components-actor__name').textContent.trim()

                    }
                    catch {
                        nme = 'Null'
                    }
                    try {
                        dte = card.querySelector('a.update-components-actor__sub-description-link').getAttribute('aria-label')

                    }
                    catch {
                        dte = 'Null'
                    }
                    try {
                        likes = card.querySelector('.social-details-social-counts__reactions-count').textContent.trim()

                    }
                    catch {
                        likes = 'Null'
                    }
                    try {
                        comments = card.querySelector('li.social-details-social-counts__comments').textContent.trim()
                        commentsTrimmed = parseInt(comments)

                    }
                    catch {
                        comments = 'Null'
                    }
                    try {
                        post = card.querySelector('.update-components-text > span').textContent.trim()

                    }
                    catch {
                        post = 'Null'
                    }
                    //console.log(nme)
                    row = '"' + nme + '"%' + '"' + dte + '"%' + '"' + likes + '"%' + '"' + commentsTrimmed + '"%' + '"' + post + '"'
                    CSV += row + '\r\n'

                });
            }
            /*
            function downloadCsv() {
                var element = document.createElement('a');
                element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(CSV));
                element.setAttribute('download', "LinkedInPosts.csv");
            
                element.style.display = 'none';
                document.body.appendChild(element);
            
                element.click();
            
                document.body.removeChild(element);
            }
            */
            setTimeout(scrapeData, 1000);
            setTimeout(downloadCsv, 3000);

            
        }

    }
);

