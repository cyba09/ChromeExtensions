let requestHeaders = []
chrome.webRequest.onBeforeSendHeaders.addListener(
  async function (info) {
    const requirements =
      (info.method === "GET") &&
      info.url.includes("appointments[expedite]");
      if (requirements){
        requestHeaders = info.requestHeaders
       
      }
    }
    
  ,
  {
    urls: ["https://ais.usvisa-info.com/*"],
  },
  [ "requestHeaders"]
);

function filterDatesInRange(dateArray, startDate, stopDate) {
  const startDateObj = new Date(startDate);
  const stopDateObj = new Date(stopDate);

  // Filter dates within the specified range
  const filteredDates = dateArray.filter(dateString => {
    const currentDateObj = new Date(dateString);
    return currentDateObj >= startDateObj && currentDateObj <= stopDateObj;
  });

  return filteredDates;
}

function showNotification(city, dte) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: '/images/icon48.png',
    title: `Appointment Date Found!`,
    message: `Found appointment date in ${city} on ${dte}`,
    priority: 1
  });
}

async function playNotification(city, dte) {
  let st = `Found appointment date in ${city} on ${dte}`
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const response = await chrome.tabs.sendMessage(tab.id, { pingback: st });
  
}

function getData(xxx){
  const cookies = xxx.Cookies
  //Location: 'T V', START DATE: '01-01-2024', END DATE: '06-01-2024', WAIT TIME: '5', AUTO BOOK: 'N'}
    let URL = xxx.URL + '/days/' + xxx.CODE + '.json?appointments[expedite]=false'
    //console.log(URL)
    const headers = new Headers();
    requestHeaders.forEach(header => {
      headers.append(header.name, header.value);
    });

    cookies.forEach(cookie => {
      headers.append(cookie.name, cookie.value);
    });
    fetch(URL, {
      method: 'GET', // or 'POST', 'PUT', etc.
      headers: headers,
    })
    .then(response => response.json()) // or response.json() for JSON
    .then(data => {
      //console.log('Fetch success:', data);
      const dateArray = data.map((dict) => dict.date);
      let start = xxx['START DATE']
      let stop = xxx['END DATE']
      const filteredDates = filterDatesInRange(dateArray, start, stop);
      if (filteredDates.length){
        //sort alphabetically and get the first element
        //sendNot
        sortedDate = filteredDates.sort()[0]
        if (xxx['AUTO BOOK'] === 'N'){
          //showNotification(xxx.CITY,sortedDate)     native noitification
          playNotification(xxx.CITY,sortedDate)
        }
        else{
          //put code to schedule here
        }
        
      }
    })
    .catch(error => {
      console.error('Fetch error:', error);
    });
}


chrome.runtime.onMessage.addListener(notify);

function notify(message) {
  if (message.query){
    const queryList = message.query
    //console.log(queryList)
    getData(queryList)

    
  }

}
///////////////////////////////////////////

