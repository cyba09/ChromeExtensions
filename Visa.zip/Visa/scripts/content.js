const elementToIndex = {
    'C': 1,
    'H': 2,
    'M': 3,
    'O': 4,
    'Q': 5,
    'T': 6,
    'V': 7
  }

const indexToCode = {
  1: 89,
  2: 90,
  3: 91,
  4: 92,
  5: 93,
  6: 94,
  7: 95
}

const codeToCity = {
  89: 'Calgary',
  90: 'Halifax',
  91: 'Montreal',
  92: 'Ottawa',
  93: 'Quebec City',
  94: 'Toronto',
  95: 'Vancouver'
}
//Location: 'T V', START DATE: '01-01-2024', END DATE: '06-01-2024', WAIT TIME: '5', AUTO BOOK: 'N'}
let isActive = true
let nIntervId = ''
const audio = new Audio(chrome.runtime.getURL('sample.mp3'));



function notifyMe(x) {
  if (isActive) {
    audio.onplay = function() {
      setTimeout(() => {
        console.log('Audio playback started');
      alert(x)
    }, 500 );
      
    };
    audio.onended = function() {
      audio.play()
    };
    audio.play();
    
    isActive = false
    clearInterval(nIntervId)
  }

}



chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        


        if (request.greeting) {
            isActive = true
            let arr = request.greeting
            const elementsArray = arr.Location.split(' ');
            const waitTime = (elementsArray.length * parseInt(arr['WAIT TIME'])) + 1
            const resultArray = elementsArray.map(element => elementToIndex[element.replace(/'/g, '')]);
            var selectElement = document.getElementById("appointments_consulate_appointment_facility_id");
            let shallowCopy = [...resultArray];
            var options = selectElement.options;
            selectElement.value = options[shallowCopy[0]].value;
            shallowCopy.shift()
            //////////
            let firstIdx = 0
            let firstInt = setInterval(()=>{
              selectElement.value = options[shallowCopy[firstIdx]].value;
              var event = new Event('change');
              selectElement.dispatchEvent(event);
              let IDX = shallowCopy[firstIdx]
              let CODE = indexToCode[IDX]
              let CITY = codeToCity[CODE]
              arr['CODE'] = CODE
              arr['CITY'] = CITY
              firstIdx = firstIdx + 1
              if (firstIdx === (shallowCopy.length - 1)){
                clearInterval(firstInt)
              }
            },(parseInt(arr['WAIT TIME'])*1000))
            /*
            shallowCopy.forEach(function(element, idx) {
              setTimeout(() => {
                selectElement.value = options[shallowCopy[idx]].value;
                console.log((parseInt(arr['WAIT TIME']) * (idx + 1)) * 1000 )
            }, (parseInt(arr['WAIT TIME']) * (idx + 1)) * 1000 );
            });/////////*/
            
          

            
           
            nIntervId = setInterval(() => {
                function selectOptionsWithDelay(optionIndexes) {
                    var selectElement = document.getElementById("appointments_consulate_appointment_facility_id");
                    var options = selectElement.options;
                  
                    function selectOptionWithDelay(index) {
                      if (index < optionIndexes.length) {
                        // Select the option at the current index
                        selectElement.value = options[optionIndexes[index]].value;
                  
                        // Trigger a change event if needed (for example, if you have event listeners)
                        var event = new Event('change');
                        selectElement.dispatchEvent(event);
                        ////////////////////////////////////////////////// TO CODE
                       
                        let IDX = optionIndexes[index]
                        let CODE = indexToCode[IDX]
                        let CITY = codeToCity[CODE]
                        arr['CODE'] = CODE
                        arr['CITY'] = CITY
                        
                        chrome.runtime.sendMessage({ query : arr })
                  
                        // Wait for 1 second before selecting the next option
                        setTimeout(function () {
                          // Move to the next option index
                          selectOptionWithDelay(index + 1);
                        }, 3000);
                      }
                    }
                  
                    // Start the loop with the first option index
                    selectOptionWithDelay(0);
                  }
                  
                  // Call the function with an array of option indexes
                  //var optionIndexesToSelect = [1,3,5,6]; // Adjust this array as needed
                  selectOptionsWithDelay(resultArray);
                
                
                
            }, (waitTime * 1000))
        }

    if (request.cease === "stop") {
      audio.pause()
      clearInterval(nIntervId)
      alert('script stopped')


    }

        if (request.pingback){
          notifyMe(request.pingback)
        }

    }
);

