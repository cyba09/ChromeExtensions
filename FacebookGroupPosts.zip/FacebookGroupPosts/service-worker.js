chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    // Check if the message is to navigate back
    if (request.action === 'navigateBack') {
      // Use the chrome.tabs API to navigate back
      chrome.tabs.getSelected(null, function(tab) {
        chrome.tabs.goBack(tab.id);
      });
    }
  });