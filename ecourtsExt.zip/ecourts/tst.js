var myHeaders = new Headers();
myHeaders.append("Accept", "application/json, text/javascript, */*; q=0.01");
myHeaders.append("Accept-Language", "en-ZA,en-GB;q=0.9,en-US;q=0.8,en;q=0.7");
myHeaders.append("Connection", "keep-alive");
myHeaders.append("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
myHeaders.append("Cookie", "PHPSESSID=46udqdv3qj5rerujr3d1evvul1; Judge_Ecourts_Token=!nADzluS5pmNoLhaUizlIzVEN2IeK+TuZYq+EQksK0M8T/D+sfe32spCcJOT+SK/ODs04ualZWqtsvSEB08sAMbKWrlhtbQ4M1tZxBta4; __session:0.6428599593008337:=https:");
myHeaders.append("Origin", "https://judgments.ecourts.gov.in");
myHeaders.append("Referer", "https://judgments.ecourts.gov.in/");
myHeaders.append("Sec-Fetch-Dest", "empty");
myHeaders.append("Sec-Fetch-Mode", "cors");
myHeaders.append("Sec-Fetch-Site", "same-origin");
myHeaders.append("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36");
myHeaders.append("X-Requested-With", "XMLHttpRequest");
myHeaders.append("sec-ch-ua", "\"Google Chrome\";v=\"119\", \"Chromium\";v=\"119\", \"Not?A_Brand\";v=\"24\"");
myHeaders.append("sec-ch-ua-mobile", "?0");
myHeaders.append("sec-ch-ua-platform", "\"Windows\"");

var raw = "val=0&lang_flg=undefined&path=2023_11_130_140&citation_year=2023&ajax_req=true&app_token=8a22223b09f746365be9bf41213ac80ae382a452cca78d4eb6514584f868dcf";

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};

fetch("https://judgments.ecourts.gov.in/pdfsearch/?p=pdf_search/openpdfcaptcha", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));