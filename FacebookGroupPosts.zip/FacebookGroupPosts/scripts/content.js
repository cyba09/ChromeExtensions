
function simulateHover(element) {
    const mouseoverEvent = new MouseEvent('mouseover', {
        bubbles: true,
        cancelable: true,
        view: window
    });
    const mouseoutEvent = new MouseEvent('mouseout', {
        bubbles: true,
        cancelable: true,
        view: window
    });

    element.dispatchEvent(mouseoverEvent);

    setTimeout(() => {
        element.dispatchEvent(mouseoutEvent);
    }, 50);
}


let num = 110
let runn = false
let stWhole = ''
let CSV = '"Author"% "Likes"% "Comments"% "Post"' + '\r\n'
let nIntervId = ''



chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {


        if (request.greeting === "download") {


            nIntervId = setInterval(() => {
                window.scrollBy(0, 1000);
                let lenLst = document.querySelectorAll('div[role="feed"] > .x1yztbdb ')
                xx = lenLst.length
                console.log(lenLst.length)
                let lastNode = lenLst[lenLst.length - 1]
                let txt = lastNode.querySelector('h3.x1heor9g > span').textContent
                //let nme = lastNode.querySelector('h3.x1heor9g > span > a').textContent
                //let allID = lastNode.querySelector('.xdj266r > div[dir="auto"]').textContent
                //let postID = allID[3].getAttribute('href')
                //console.log(allID)
                if (txt.includes(' created the group ')) {

                    console.log('done')
                    function functionWithTimeout() {
                        let seeMoreLst = document.querySelectorAll('div[dir="auto"] > .x1i10hfl')
                        seeMoreLst.forEach((element, index) => {
                            setTimeout(() => {
                                element.click();
                            }, index * 50);
                        });
                        /////////////////////////////////////////////////////////
                    }
                    setTimeout(functionWithTimeout, 2000);
                    setTimeout(functionWithOutTimeout, 5000);
                    setTimeout(downloadCsv, 8000)
                    //setTimeout(functionHover,1000)
                    //setTimeout(functionPrint,7000)

                    function functionHover() {
                        let links = document.querySelectorAll('a[href="#"]')  //a[href="#"]
                        links.forEach((element, index) => {
                            setTimeout(() => {
                                simulateHover(element);
                            }, index * 100); // 50ms for hover in and 50ms before moving to the next element
                        });
                    }
                    function functionPrint() {
                        let finalLinks = document.querySelectorAll('a')
                        const hrefArray = Array.from(finalLinks).map(aTag => (aTag ? aTag.getAttribute('href') : null));
                        const filteredArray = hrefArray.filter(item => item && item.includes('/posts/'));
                        filteredArray.forEach(element => {
                            console.log(element)
                        });
                    }

                    /*
                    let links = document.querySelectorAll('a')  //a[href="#"]
                    
                    links.forEach(link => {
                        var event = new MouseEvent('mouseover', {
                            'view': window,
                            'bubbles': true,
                            'cancelable': true
                          });
                          
                          link.dispatchEvent(event);
                          const mouseoutEvent = new MouseEvent('mouseout', {
                            bubbles: true,
                            cancelable: true,
                            view: window
                          });
                          link.dispatchEvent(mouseoutEvent);
                    })
                    
                    
                    let finalLinks = document.querySelectorAll('a')
                    const hrefArray = Array.from(finalLinks).map(aTag => (aTag ? aTag.getAttribute('href') : null));
                    const filteredArray = hrefArray.filter(item => item && item.includes('/posts/'));
                    filteredArray.forEach(element => {
                        console.log(element)
                    });
                    */
                    //let lenLst = document.querySelectorAll('.x1rdy4ex > div')

                    function functionWithOutTimeout() {
                        lenLst.forEach(card => {
                            let row = ''
                            let nme = ''
                            let likes = ''
                            let comments = ''
                            let post = ''
                            try {
                                nme = card.querySelector('h3.x1heor9g > span > span > a').textContent

                            }
                            catch {
                                nme = 'Null'
                            }
                            try {
                                likes = card.querySelector('.xrbpyxo > span > .xt0b8zv').textContent

                            }
                            catch {
                                likes = 'Null'
                            }
                            try {
                                comments = card.querySelector('.x9f619 > .x4k7w5x > .x1i10hfl').textContent

                            }
                            catch {
                                comments = 'Null'
                            }
                            try {
                                post = card.querySelector('div[dir="auto"]').textContent

                            }
                            catch {
                                post = 'Null'
                            }
                            row = '"' + nme + '",' + '"' + likes + '",' + '"' + comments + '",' + '"' + post + '"'
                            CSV += row + '\r\n'


                        });
                    }

                    function downloadCsv() {
                        var element = document.createElement('a');
                        element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(CSV));
                        element.setAttribute('download', "FacebookPosts.csv");

                        element.style.display = 'none';
                        document.body.appendChild(element);

                        element.click();

                        document.body.removeChild(element);
                    }

                    clearInterval(nIntervId);

                }
            }, 1000, num)


        }

        if (request.greeting === "stop") {
            clearInterval(nIntervId)
            let lenLst = document.querySelectorAll('div[role="feed"] > .x1yztbdb ')
            function functionWithTimeout() {
                let seeMoreLst = document.querySelectorAll('div[dir="auto"] > .x1i10hfl')
                seeMoreLst.forEach((element, index) => {
                    setTimeout(() => {
                        element.click();
                    }, index * 50);
                });
                /////////////////////////////////////////////////////////
            }
            setTimeout(functionWithTimeout, 2000);
            setTimeout(functionWithOutTimeout, 5000);
            setTimeout(downloadCsv, 8000)
            //setTimeout(functionHover,1000)
            //setTimeout(functionPrint,7000)

            function functionWithOutTimeout() {
                lenLst.forEach(card => {
                    let row = ''
                    let nme = ''
                    let likes = ''
                    let comments = ''
                    let post = ''
                    try {
                        nme = card.querySelector('h3.x1heor9g > span > span > a').textContent

                    }
                    catch {
                        nme = 'Null'
                    }
                    try {
                        likes = card.querySelector('.xrbpyxo > span > .xt0b8zv').textContent

                    }
                    catch {
                        likes = 'Null'
                    }
                    try {
                        comments = card.querySelector('.x9f619 > .x4k7w5x > .x1i10hfl').textContent

                    }
                    catch {
                        comments = 'Null'
                    }
                    try {
                        post = card.querySelector('div[dir="auto"]').textContent

                    }
                    catch {
                        post = 'Null'
                    }
                    row = '"' + nme + '"%' + '"' + likes + '"%' + '"' + comments + '"%' + '"' + post + '"'
                    CSV += row + '\r\n'


                });
            }

            function downloadCsv() {
                var element = document.createElement('a');
                element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(CSV));
                element.setAttribute('download', "FacebookPosts.csv");

                element.style.display = 'none';
                document.body.appendChild(element);

                element.click();

                document.body.removeChild(element);
            }
        }

    }
);

